//
//  NotesTableView.swift
//  FSNotes
//
//  Created by Oleksandr Glushchenko on 7/31/17.
//  Copyright © 2017 Oleksandr Glushchenko. All rights reserved.
//

import Carbon
import Cocoa

class NotesTableView: NSTableView,
    NSTableViewDataSource,
    NSTableViewDelegate {
    
    private var noteList = [Note]()
    
    var defaultCell = NoteCellView()
    var pinnedCell = NoteCellView()
    var storage = Storage.shared()

    public var history = [URL]()
    public var historyPosition = 0
    
    private var selectedHistory: IndexSet?

    override func awakeFromNib() {
        super.awakeFromNib()
        allowsTypeSelect = false
        self.gridColor = NSColor.clear
        self.dataSource = self
        self.delegate = self
        wantsLayer = true
    }
    
    override func validateUserInterfaceItem(_ item: NSValidatedUserInterfaceItem) -> Bool {
        if item.action == #selector(selectAll(_:)) {
            return numberOfRows > 0 && allowsMultipleSelection
        }
        
        if item.action == #selector(copy(_:)) ||
            item.action == #selector(delete(_:)) ||
            item.action == #selector(forceDeleteNote(_:)) {
            return selectedRowIndexes.count > 0
        }

        return super.validateUserInterfaceItem(item)
    }

    override func keyDown(with event: NSEvent) {
        guard let vc = self.window?.contentViewController as? ViewController else {
            super.keyDown(with: event)
            return
        }
        
        if event.keyCode == kVK_ANSI_N && event.modifierFlags.contains(.control) {
            vc.noteDown(NSMenuItem())
            return
        }
        
        if event.keyCode == kVK_ANSI_P && event.modifierFlags.contains(.control) {
            vc.noteUp(NSMenuItem())
            return
        }
        
        super.keyDown(with: event)
    }
    
    override func keyUp(with event: NSEvent) {
        guard let vc = self.window?.contentViewController as? ViewController else {
            super.keyUp(with: event)
            return
        }
        
        if event.keyCode == kVK_Tab && !event.modifierFlags.contains(.control) {
            if vc.editor?.isPreviewEnabled() == true {
                DispatchQueue.main.async {
                    if let webView = vc.editor.markdownView?.webView {
                        NSApp.mainWindow?.makeFirstResponder(webView)
                    }
                }
            } else {
                vc.focusEditArea()
            }

            return
        }
        
        super.keyUp(with: event)
    }
    
    override func mouseDown(with event: NSEvent) {
        guard let vc = self.window?.contentViewController as? ViewController else { return }
        
        let point = convert(event.locationInWindow, from: nil)
        let row = self.row(at: point)
        
        if row >= 0, noteList.indices.contains(row) {
            let note = noteList[row]
            if event.modifierFlags.contains(.option) {
                NSWorkspace.shared.activateFileViewerSelecting([note.url])
                return
            }
        }
        
        if let selectedProject = vc.sidebarOutlineView.getSelectedProject(),
            selectedProject.isLocked()
        {
            vc.sidebarOutlineView.toggleFolderLock(NSMenuItem())
            return
        }
        
        UserDataService.instance.searchTrigger = false

        super.mouseDown(with: event)
    }

    func tableView(_ tableView: NSTableView, shouldSelectRow row: Int) -> Bool {
        if (noteList.indices.contains(row)) {
            saveNavigationHistory(note: noteList[row])
        }
        return true
    }

    override func rightMouseDown(with event: NSEvent) {
        UserDataService.instance.searchTrigger = false

        NSApp.activate(ignoringOtherApps: true)

        if let window = self.window {
            window.makeKeyAndOrderFront(nil)
        }

        let point = convert(event.locationInWindow, from: nil)
        let rowIndex = row(at: point)
        guard rowIndex >= 0, rowIndex < numberOfRows else { return }

        saveNavigationHistory(note: noteList[rowIndex])

        window?.makeFirstResponder(self)

        if !selectedRowIndexes.contains(rowIndex) {
            selectRowIndexes(IndexSet(integer: rowIndex), byExtendingSelection: false)
            scrollRowToVisible(rowIndex)
        }

        if rowView(atRow: rowIndex, makeIfNecessary: false) as? NoteRowView != nil,
           let menu = menu {
            NSMenu.popUpContextMenu(menu, with: event, for: self)
        }
    }

    @IBAction func delete(_ sender: Any) {
        guard let vc = ViewController.shared(),
              let notes = getSelectedNotes() else { return }

        vc.removeNotes(notes: notes, forceRemove: false, rows: selectedRowIndexes)
    }
    
    @IBAction func forceDeleteNote(_ sender: Any) {
        guard let vc = ViewController.shared(),
              let notes = getSelectedNotes() else { return }

        vc.removeNotes(notes: notes, forceRemove: true, rows: selectedRowIndexes)
    }
    
    public func getNoteList() -> [Note] {
        return noteList
    }
    
    public func setNoteList(notes: [Note]) {
       noteList = notes
    }
    
    public func countNotes() -> Int {
        return noteList.count
    }
    
    public func getIndex(for note: Note) -> Int? {
        return noteList.firstIndex(where: {$0 === note})
    }
    
    public func getNote(at index: Int) -> Note? {
        return noteList.indices.contains(index) ? noteList[index] : nil
    }
    
    // Custom note highlight style
    func tableView(_ tableView: NSTableView, rowViewForRow row: Int) -> NSTableRowView? {
        return NoteRowView()
    }
    
    // Populate table data
    func numberOfRows(in tableView: NSTableView) -> Int {
        return noteList.count
    }

    func tableView(_ tableView: NSTableView, heightOfRow row: Int) -> CGFloat {
        let height = CGFloat(21 + UserDefaultsManagement.cellSpacing)

        guard row < noteList.count else { return height }

        let note = noteList[row]
        
        if !note.isLoaded && !note.isLoadedFromCache {
            note.load()
        }
        
        if !note.isParsed {
            note.loadPreviewInfo()
        }

        if !UserDefaultsManagement.horizontalOrientation
            && !UserDefaultsManagement.hidePreviewImages,
            let urls = note.imageUrl,
            urls.count > 0{

            if note.preview.count == 0 {
                if note.getTitle() != nil {
                    // Title + image
                    return 79 + 17
                }

                // Images only
                return 79
            }

            // Title + Prevew + Images
            return height + 58
        }

        // Title + preview
        return height
    }

    // On selected row show notes in right panel
    func tableViewSelectionDidChange(_ notification: Notification) {
        selectedHistory = selectedRowIndexes

        let vc = self.window?.contentViewController as! ViewController
        
        defer {
            vc.updateNotesCounter()
        }
        
        if vc.editAreaScroll.isFindBarVisible {
            let menu = NSMenuItem(title: "", action: nil, keyEquivalent: "")
            menu.tag = NSTextFinder.Action.hideFindInterface.rawValue
            vc.editor.performTextFinderAction(menu)
        }

        if UserDataService.instance.isNotesTableEscape {
            if vc.sidebarOutlineView.selectedRow == -1 {
                UserDataService.instance.isNotesTableEscape = false
            }
            
            vc.sidebarOutlineView.deselectAll(nil)
            vc.sidebarOutlineView.reloadTags()
            vc.editor.clear()
            return
        }

        // Select row
        if (noteList.indices.contains(selectedRow)) {
            let note = noteList[selectedRow]

            guard selectedRowIndexes.count == 0x01 else {
                vc.editor.clear()
                return
            }
            
            vc.editor.changePreviewState(note.previewState)
            vc.editor.fill(note: note, highlight: true)

            if UserDefaultsManagement.focusInEditorOnNoteSelect && !UserDataService.instance.searchTrigger {
                vc.focusEditArea()
            }

            return
        }

        // Clean
        vc.editor.clear()

        if !UserDefaultsManagement.inlineTags {
            vc.sidebarOutlineView.deselectAllTags()
        }
    }
    
    func tableView(_ tableView: NSTableView, objectValueFor tableColumn: NSTableColumn?, row: Int) -> Any? {
        if (noteList.indices.contains(row)) {
            return noteList[row]
        }
        return nil
    }
    
    func tableView(_ tableView: NSTableView, writeRowsWith rowIndexes: IndexSet, to pboard: NSPasteboard) -> Bool {
        var urls = [URL]()
        var contentUrls = [URL]()
        
        for row in rowIndexes {
            let note = noteList[row]
            urls.append(note.url)
            
            if let url = note.getContentFileURL() {
                contentUrls.append(url)
            }
        }
        
        pboard.clearContents()
        pboard.writeObjects(contentUrls as [NSPasteboardWriting])
        
        if let data = try? NSKeyedArchiver.archivedData(withRootObject: urls, requiringSecureCoding: true) {
            pboard.setData(data, forType: NSPasteboard.note)
        }
        
        return true
    }

    @IBAction func copy(_ sender: Any) {
        guard let vc = ViewController.shared() else { return }

        vc.saveTextAtClipboard()
    }
    
    func getNoteFromSelectedRow() -> Note? {
        var note: Note? = nil
        let selected = self.selectedRow

        if (selected < 0) {
            return nil
        }
        
        if (noteList.indices.contains(selected)) {
            note = noteList[selected]
        }
        
        return note
    }
    
    func getSelectedNote() -> Note? {
        var note: Note? = nil
        let row = selectedRow
        if (noteList.indices.contains(row)) {
            note = noteList[row]
        }
        return note
    }
    
    func getSelectedNotes() -> [Note]? {
        var notes = [Note]()
        
        for row in selectedRowIndexes {
            if (noteList.indices.contains(row)) {
                notes.append(noteList[row])
            }
        }
        
        if notes.isEmpty {
            return nil
        }
        
        return notes
    }
    
    public func deselectNotes() {
        self.deselectAll(nil)
    }
    
    override func performKeyEquivalent(with event: NSEvent) -> Bool {
        if event.modifierFlags.contains(.control) && event.keyCode == kVK_Tab {
            return true
        }
        
        return super.performKeyEquivalent(with: event)
    }
    
    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        guard noteList.indices.contains(row) else {
            return nil
        }
        
        let note = noteList[row]
        if (note.isPinned) {
            pinnedCell = makeCell(note: note)
            pinnedCell.pin.frame.size.width = 23
            return pinnedCell
        }
        
        defaultCell = makeCell(note: note)
        defaultCell.pin.frame.size.width = 0
        return defaultCell
    }
    
    func tableView(_ tableView: NSTableView, rowActionsForRow row: Int, edge: NSTableView.RowActionEdge) -> [NSTableViewRowAction] {
        guard edge == .trailing else { return [] }
        guard noteList.indices.contains(row) else { return [] }
        
        let deleteAction = NSTableViewRowAction(style: .destructive, title: NSLocalizedString("Delete", comment: "")) { [weak self] (action, row) in
            guard let self = self else { return }
            guard self.noteList.indices.contains(row) else { return }
            let noteToDelete = self.noteList[row]
            
            if let vc = self.window?.contentViewController as? ViewController {
                vc.removeNotes(notes: [noteToDelete])
            }
        }
        
        deleteAction.backgroundColor = .systemRed
        
        return [deleteAction]
    }
    
    func makeCell(note: Note) -> NoteCellView {
        let cell = makeView(withIdentifier: NSUserInterfaceItemIdentifier(rawValue: "NoteCellView"), owner: self) as! NoteCellView

        cell.imageKeys = []
        cell.timestamp = nil
        
        cell.imagePreview.image = nil
        cell.imagePreview.isHidden = true
        cell.imagePreviewSecond.image = nil
        cell.imagePreviewSecond.isHidden = true
        cell.imagePreviewThird.image = nil
        cell.imagePreviewThird.isHidden = true
        
        cell.configure(note: note)
        cell.loadImagesPreview()
        cell.attachHeaders(note: note)

        return cell
    }
    
    override func willOpenMenu(_ menu: NSMenu, with event: NSEvent) {
        guard let vc = ViewController.shared() else { return }
        
        if clickedRow > -1 {
            selectRowIndexes([clickedRow], byExtendingSelection: false)
        }

        if selectedRow < 0 { return }
        menu.autoenablesItems = false
        
        for menuItem in menu.items {
            if vc.processFileMenuItems(menuItem, menuId: "popup") {
                menuItem.isEnabled = true
            } else {
                menuItem.isEnabled = vc.processShareMenuItems(menuItem, menuId: "popup")
            }
        }

        vc.loadMoveMenu()
    }

    public func selectCurrent() {
        guard noteList.count > 0 else { return }

        UserDataService.instance.searchTrigger = false

        let i = selectedRowIndexes.count > 0 ? selectedRowIndexes : [0]

        if let first = i.first {
            saveNavigationHistory(note: noteList[first])
            selectRowIndexes(i, byExtendingSelection: false)
            scrollRowToVisible(first)
        }
    }

    public func selectNext() {
        UserDataService.instance.searchTrigger = false
        
        let i = selectedRow + 1
        guard noteList.indices.contains(i) else { return }
        
        saveNavigationHistory(note: noteList[i])
        selectRowIndexes([i], byExtendingSelection: false)
        scrollRowToVisible(i)
    }

    public func selectPrev() {
        UserDataService.instance.searchTrigger = false
        
        let i = selectedRow - 1
        guard noteList.indices.contains(i) else { return }
        
        saveNavigationHistory(note: noteList[i])
        selectRowIndexes([i], byExtendingSelection: false)
        scrollRowToVisible(i)
    }
    
    public func selectRow(_ i: Int) {
        if (noteList.indices.contains(i)) {
            DispatchQueue.main.async {
                self.selectRowIndexes([i], byExtendingSelection: false)
                self.scrollRowToVisible(i)
            }
        }
    }

    public func selectRowAndSidebarItem(note: Note) {
        guard let vc = ViewController.shared() else { return }

        if let index = getIndex(for: note) {
            selectRow(index)
        } else {
            vc.sidebarOutlineView.select(note: note)
        }
    }

    func setSelected(note: Note) {
        if let i = getIndex(for: note) {
            selectRow(i)
            scrollRowToVisible(i)
        }
    }
    
    public func select(note: Note) {
        if let i = getIndex(for: note) {
            if noteList.indices.contains(i) {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.selectRowIndexes([i], byExtendingSelection: false)
                    self.scrollRowToVisible(i)
                }
            }
        }
    }
    
    public func removeRows(notes: [Note]) {
        guard let vc = ViewController.shared() else { return }

        var indexSet = IndexSet()
        for note in notes {
            if let i = noteList.firstIndex(where: {$0 === note}) {
                indexSet.insert(i)
            }
        }
        
        guard !indexSet.isEmpty else { return }
        
        beginUpdates()
        
        for i in indexSet.sorted().reversed() {
            noteList.remove(at: i)
        }
        
        removeRows(at: indexSet, withAnimation: .slideDown)
        endUpdates()

        if UserDefaultsManagement.inlineTags {
            vc.sidebarOutlineView.removeTags(notes: notes)
        }
    }
    
    public func insertRows(notes: [Note]) {
        guard let vc = self.window?.contentViewController as? ViewController else { return }
        var insert = [Note]()
        
        for note in notes {
            if noteList.first(where: { $0.isEqualURL(url: note.url) }) == nil, vc.storage.searchQuery.isFit(note: note) {
                insert.append(note)
            }
        }
        
        guard !insert.isEmpty else { return }
        beginUpdates()
        
        noteList.append(contentsOf: insert)
        self.noteList = vc.storage.sortNotes(noteList: self.noteList)
        
        var indexSet = IndexSet()
        for note in insert {
            if let noteIndex = self.noteList.firstIndex(of: note) {
                indexSet.insert(noteIndex)
            }
        }
        
        self.insertRows(at: indexSet, withAnimation: .effectFade)
        endUpdates()
        
        for note in insert {
            vc.sidebarOutlineView.insertTags(note: note)
        }
    }
    
    private func reloadRows(notes: [Note]) {
        for note in notes {
            note.invalidateCache()
            note.loadPreviewInfo()
            self.performReload(note: note)
        }
    }
    
    @objc public func unDelete(_ urls: [URL: URL]) {
        guard let vc = ViewController.shared() else { return }
        var invertedMapping: [URL: URL] = [:]
        
        for (src, dst) in urls {
            do {
                if let note = storage.getBy(url: src) {
                    storage.removeBy(note: note)
                    if let destination = Storage.shared().getProjectByNote(url: dst) {
                        note.moveImages(to: destination)
                    }
                }
                try FileManager.default.moveItem(at: src, to: dst)
                invertedMapping[dst] = src
            } catch {
                print(error)
            }
        }
        
        // Register redo (delete again)
        if let md = AppDelegate.mainWindowController, !invertedMapping.isEmpty {
            let undoManager = md.notesListUndoManager
            undoManager.registerUndo(withTarget: self) { notesTableView in
                let restoredNotes = invertedMapping.keys.compactMap { url in
                    vc.storage.getBy(url: url)
                }
                
                if !restoredNotes.isEmpty {
                    vc.removeNotes(notes: restoredNotes, forceRemove: false, rows: nil)
                }
            }
            undoManager.setActionName(NSLocalizedString("Delete", comment: ""))
        }
    }
    
    public func countVisiblePinned() -> Int {
        var i = 0
        for note in noteList {
            if (note.isPinned) {
                i += 1
            }
        }
        return i
    }

    public func reloadRow(note: Note) {
        DispatchQueue.global(qos: .userInitiated).async {
            self.reloadRowSync(note: note)
        }
    }
    
    public func reloadRowSync(note: Note) {
        note.invalidateCache()
        note.loadPreviewInfo()

        DispatchQueue.main.async {
            self.performReload(note: note)
        }
    }
    
    private func performReload(note: Note) {
        guard let i = self.noteList.firstIndex(of: note) else { return }
        let urls = note.imageUrl

        // Heights are cached even for rows that do not currently have a cell view.
        self.noteHeightOfRows(withIndexesChanged: [i])
        
        if let cell = self.view(atColumn: 0, row: i, makeIfNecessary: false) as? NoteCellView {
            cell.date.stringValue = note.getDateForLabel()
            cell.loadImagesPreview(position: i, urls: urls)
            cell.attachHeaders(note: note)
            cell.renderPin()
            cell.applyPreviewStyle()
        }
    }
    
    public func reloadDate(note: Note) {
        DispatchQueue.main.async {
            if self.numberOfRows > 0, let i = self.noteList.firstIndex(of: note) {
                if let cell = self.view(atColumn: 0, row: i, makeIfNecessary: false) as? NoteCellView {
                    cell.date.stringValue = note.getDateForLabel()
                }
            }
        }
    }

    public func saveNavigationHistory(note: Note) {
        guard history.last != note.url else {
            historyPosition = history.count - 1
            return
        }

        history.append(note.url)
        
        if history.count > 100 {
            history.removeFirst()
        } else {
            historyPosition = history.count - 1
        }
    }
    
    public func enableLockedProject() {
        ViewController.shared()?.lockedFolder.isHidden = false
        clean()
    }
    
    public func disableLockedProject() {
        ViewController.shared()?.lockedFolder.isHidden = true
    }
    
    public func clean() {
        noteList.removeAll()
        reloadData()
    }
    
    public func doVisualChanges(results: ([Note], [Note], [Note])) {
        guard results.0.count > 0 || results.1.count > 0 || results.2.count > 0 else {
            return
        }

        DispatchQueue.main.async {
            if let vc = ViewController.shared(), vc.splitView.subviews[0].frame.width > 10 {
                self.removeRows(notes: results.0)
                self.insertRows(notes: results.1)
                self.reloadRows(notes: results.2)
            }
        }
    }
}
