# 3. Shortcuts

FSNotes respects mouseless usage, it is shortcuts friendly app. 

The most important combination you must learn:

`cmd - slash` - disable / enable preview mode.

Alternative: you can do same in menu bar `View - Toggle Preview`

## Global

- `cmd + option + shift + L` - open main window and focus search bar
- `cmd + option + shift + n` - save clipboard
- `enter` - move focus right (deeper); sidebar > note list > note
- `cmd + enter` - move focus left (higher); note > note list > sidebar

## Search and create field

- `down arrow` - move focus on notes list
- `enter` - make note

## Main window

- `esc` - move cursor into search bar and clear edit/search fields
- `cmd + L` - move cursor into search bar
- `tab` - go to next field
- `cmd + slash` - preview mode (markdown only)
- `up, down arrows` - select note
- `cmd + j` - next note
- `cmd + k` - previous note

## Notes list

- `cmd + delete` - remove note
- `cmd + r` - rename note
- `cmd + 8` - pin note
- `cmd + 7` - remove encryption (un encrypt previously encrypted note)
- `cmd + n` - new note
- `cmd + shift + n` - new note in new window
- `cmd + option + n` - new folder
- `ctrl + cmd + e` – open selected in external editor
- `ctrl + cmd + o` – show selected in finder
- `shift + cmd + m` – move selected note in storage
- `shift + cmd + b` – hide sidebar
- `cmd + s` – save revision in git
- `cmd + d` – duplicate note
- `cmd + alt + l` - encrypt/decrypt note (AES 256)

## Editor

- `fn + f5` - autocomplete note name
- ``cmd + ` ``, or click `View - Toggle preview` - for enable or disable preview rendered markdown


