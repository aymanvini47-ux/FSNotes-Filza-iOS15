//
//  EditTextView.swift
//  FSNotes iOS
//
//  Created by Oleksandr Glushchenko on 1/29/18.
//  Copyright © 2018 Oleksandr Glushchenko. All rights reserved.
//

import UIKit
import MobileCoreServices
import UniformTypeIdentifiers

class EditTextView: UITextView, UITextViewDelegate, NSLayoutManagerDelegate {

    public var textStorageProcessor: TextStorageProcessor?
    
    public var isNoteLoading = false
    public var isAllowedScrollRect: Bool?
    public var typingFont: UIFont?
    public var note: Note?
    public var lasTouchPoint: CGPoint?
    public var imagesLoaderQueue = OperationQueue.init()
    public var keyboardIsOpened = true
    public var callCounter = 0
    public var isUpdating = false
    private var updatingConcealedSyntax = false
    private let codeBlockBackground = CAShapeLayer()

    @objc func refreshConcealedSyntax() {
        guard !updatingConcealedSyntax, markedTextRange == nil,
              textStorage.length > 0 else { return }
        updatingConcealedSyntax = true
        defer { updatingConcealedSyntax = false }

        let changed = NotesTextProcessor.refreshConcealedSyntax(
            in: textStorage, selection: selectedRange,
            codeBlockRanges: note?.codeBlockRangesCache ?? [], isFocused: isFirstResponder
        )
        if changed {
            setNeedsDisplay()
            setNeedsLayout()
        }

        if let font = typingAttributes[NotesTextProcessor.concealedSyntaxFont] as? UIFont {
            typingAttributes[.font] = font
            typingAttributes[.foregroundColor] = NotesTextProcessor.fontColor
        }
        typingAttributes.removeValue(forKey: NotesTextProcessor.concealedSyntaxFont)
        typingAttributes.removeValue(forKey: NotesTextProcessor.concealedSyntaxHidden)
        typingAttributes.removeValue(forKey: NotesTextProcessor.collapsedCodeFence)
    }

    func layoutManager(_ layoutManager: NSLayoutManager, shouldGenerateGlyphs glyphs: UnsafePointer<CGGlyph>,
                       properties: UnsafePointer<NSLayoutManager.GlyphProperty>, characterIndexes: UnsafePointer<Int>,
                       font: UIFont, forGlyphRange glyphRange: NSRange) -> Int {
        return NotesTextProcessor.generateConcealedGlyphs(layoutManager, glyphs: glyphs, properties: properties,
                                                        characterIndexes: characterIndexes, font: font, glyphRange: glyphRange)
    }

    func layoutManager(_ layoutManager: NSLayoutManager,
                       shouldSetLineFragmentRect lineFragmentRect: UnsafeMutablePointer<CGRect>,
                       lineFragmentUsedRect: UnsafeMutablePointer<CGRect>,
                       baselineOffset: UnsafeMutablePointer<CGFloat>,
                       in textContainer: NSTextContainer, forGlyphRange glyphRange: NSRange) -> Bool {
        let characters = layoutManager.characterRange(forGlyphRange: glyphRange, actualGlyphRange: nil)
        guard characters.location < textStorage.length,
              textStorage.attribute(NotesTextProcessor.collapsedCodeFence, at: characters.location, effectiveRange: nil) as? Bool == true else { return false }
        lineFragmentRect.pointee.size.height = 0.1
        lineFragmentUsedRect.pointee.size.height = 0.1
        baselineOffset.pointee = 0.1
        return true
    }
    
    required init?(coder: NSCoder) {
        if #available(iOS 13.2, *) {
            super.init(coder: coder)
        }
        else {
            super.init(frame: .zero, textContainer: nil)
            self.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            self.contentMode = .scaleToFill

            self.isScrollEnabled = false   // causes expanding height

            // Auto Layout
            self.translatesAutoresizingMaskIntoConstraints = false
            self.font = UIFont(name: "HelveticaNeue", size: 18)
        }

        autocorrectionType = UserDefaultsManagement.editorAutocorrection ? .yes : .no
        spellCheckingType = UserDefaultsManagement.editorSpellChecking ? .yes : .no
    }

    override func becomeFirstResponder() -> Bool {
        textStorage.removeHighlight()
        
        let became = super.becomeFirstResponder()
        refreshConcealedSyntax()
        return became
    }

    override func resignFirstResponder() -> Bool {
        let resigned = super.resignFirstResponder()
        if resigned { refreshConcealedSyntax() }
        return resigned
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        
        if !isFirstResponder && window != nil {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                guard let self = self else { return }
                
                if !self.isFirstResponder && self.window != nil {
                    _ = self.becomeFirstResponder()
                }
            }
        }
    }

    public func initTextStorage() {
        layoutManager.delegate = self
        NotificationCenter.default.removeObserver(self, name: UITextView.textDidChangeNotification, object: self)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshConcealedSyntax), name: UITextView.textDidChangeNotification, object: self)
        let processor = TextStorageProcessor()
        processor.editor = self
        
        textStorageProcessor = processor
        textStorage.delegate = processor
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        updateCodeBlockBackground()
    }

    private func updateCodeBlockBackground() {
        let path = UIBezierPath()
        for block in note?.codeBlockRangesCache ?? [] {
            let range = NotesTextProcessor.codeBlockBackgroundRange(in: textStorage, range: block)
            guard range.length > 0 else { continue }
            let glyphs = layoutManager.glyphRange(forCharacterRange: range, actualCharacterRange: nil)
            let bounds = layoutManager.boundingRect(forGlyphRange: glyphs, in: textContainer)
            let inset = max(0, textContainer.lineFragmentPadding - 5)
            let rect = CGRect(x: textContainerInset.left + inset, y: textContainerInset.top + bounds.minY,
                              width: max(0, textContainer.size.width - 2 * inset), height: bounds.height)
            guard !rect.isEmpty else { continue }
            path.append(UIBezierPath(roundedRect: rect, cornerRadius: 5))
        }

        // Keep decoration below UIKit's text/selection layers without replacing TextKit.
        if codeBlockBackground.superlayer == nil {
            layer.insertSublayer(codeBlockBackground, at: 0)
        }
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        codeBlockBackground.path = path.cgPath
        codeBlockBackground.fillColor = NotesTextProcessor.getHighlighter().options.style.backgroundColor.cgColor
        codeBlockBackground.strokeColor = UIColor.lightGray.cgColor
        codeBlockBackground.lineWidth = 1
        CATransaction.commit()
    }

    override func selectionRects(for range: UITextRange) -> [UITextSelectionRect] {
        let selectionRects = super.selectionRects(for: range)

        let fontHeight = UserDefaultsManagement.noteFont.lineHeight
        let lineSpacing = CGFloat(UserDefaultsManagement.editorLineSpacing)
        let endCharacterIndex = offset(from: beginningOfDocument, to: range.end)
        let endParRange = textStorage.mutableString.paragraphRange(for: NSRange(location: endCharacterIndex, length: 0))

        var lastWideRect: UITextSelectionRect?
        if selectionRects.count > 2 {
            lastWideRect = selectionRects[selectionRects.count - 3]
        }

        var result = [UITextSelectionRect]()
        for selectionRect in selectionRects {
            if selectionRect.rect.width == 0 {
                let customRect = CGRect(x: selectionRect.rect.origin.x, y: selectionRect.rect.origin.y - lineSpacing / 2, width: 0, height: fontHeight + lineSpacing)
                let sel = EditorSelectionRect(originalRect: selectionRect, rect: customRect)
                result.append(sel)
            } else {
                var heightOffset = CGFloat(0)

                if endParRange.upperBound == textStorage.length && lastWideRect == selectionRect {
                    heightOffset += lineSpacing
                }

                let customRect = CGRect(x: selectionRect.rect.origin.x, y: selectionRect.rect.origin.y - lineSpacing / 2, width: selectionRect.rect.width, height: selectionRect.rect.height + heightOffset)

                let selectionRect = EditorSelectionRect(originalRect: selectionRect, rect: customRect)
                result.append(selectionRect)
            }
        }

        return result
    }

    override func caretRect(for position: UITextPosition) -> CGRect {
        let characterIndex = offset(from: beginningOfDocument, to: position)

        guard layoutManager.isValidGlyphIndex(characterIndex) else {
            return super.caretRect(for: position)
        }

        let glyphIndex = layoutManager.glyphIndexForCharacter(at: characterIndex)
        let usedLineFragment = layoutManager.lineFragmentUsedRect(forGlyphAt: glyphIndex, effectiveRange: nil)

        guard !usedLineFragment.isEmpty else {
            return super.caretRect(for: position)
        }

        var caretRect = super.caretRect(for: position)
        caretRect.origin.y = usedLineFragment.origin.y + textContainerInset.top
        caretRect.size.height = usedLineFragment.size.height - CGFloat(UserDefaultsManagement.editorLineSpacing) / 2

        return caretRect
    }

    override func scrollRectToVisible(_ rect: CGRect, animated: Bool) {
        guard isAllowedScrollRect == true else { return }

        callCounter += 1

        if keyboardIsOpened {
            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.8, delay: 0, options: .beginFromCurrentState, animations: {
                    super.scrollRectToVisible(rect, animated: false)
                })
            }

            if callCounter > 2 {
                keyboardIsOpened = false
                callCounter = 0
            }
        } else {
            super.scrollRectToVisible(rect, animated: animated)
        }
    }

    override func cut(_ sender: Any?) {
        let range = selectedRange
        guard range.length > 0 else { return }

        let selectedString = textStorage.attributedSubstring(from: range)
        let attributedString = NSMutableAttributedString(attributedString: selectedString)
            .unloadTasks()
        attributedString.saveData()

        super.cut(sender)
        
        do {
            let data = try NSKeyedArchiver.archivedData(
                withRootObject: attributedString,
                requiringSecureCoding: false
            )

            UIPasteboard.general.setItems([
                [
                    UIPasteboard.attributed: data,
                    UTType.plainText.identifier: attributedString.string
                ]
            ])
        } catch {
            print("Serialization error: \(error)")
        }
    }

    override func paste(_ sender: Any?) {
        isUpdating = true
        
        defer {
            DispatchQueue.main.async {
                self.isUpdating = false
            }
        }
        
        let pb = UIPasteboard.general
        var toInsert: NSAttributedString?

        if let imageData = pb.data(forPasteboardType: UTType.png.identifier) ??
                           pb.data(forPasteboardType: UTType.jpeg.identifier) ??
                           pb.data(forPasteboardType: UTType.image.identifier) {

            toInsert = NSMutableAttributedString.build(data: imageData)
        }

        else if let data = pb.data(forPasteboardType: UIPasteboard.attributed) {
            do {
                if let attributed = try NSKeyedUnarchiver.unarchivedObject(
                    ofClass: NSAttributedString.self,
                    from: data
                ) {
                    let mutable = NSMutableAttributedString(attributedString: attributed)
                    mutable.loadTasks()
                    toInsert = mutable
                }
            } catch {
                print("Paste error: \(error)")
            }
        }

        else if let plain = pb.string {
            let mutable = NSMutableAttributedString(string: plain)
            mutable.loadTasks()
            mutable.loadFont()
            toInsert = mutable
        }

        guard let attrToInsert = toInsert else {
            super.paste(sender)
            return
        }

        let range = self.selectedRange
        if let should = delegate?.textView?(self, shouldChangeTextIn: range, replacementText: attrToInsert.string), !should {
            return
        }

        self.insertAttributedText(attrToInsert)
    }

    override func copy(_ sender: Any?) {
        guard selectedRange.length > 0 else { return }

        let selectedString = textStorage.attributedSubstring(from: self.selectedRange)
        
        let attributedString = NSMutableAttributedString(attributedString: selectedString).unloadTasks()
        attributedString.saveData()

        do {
            let data = try NSKeyedArchiver.archivedData(
                withRootObject: attributedString,
                requiringSecureCoding: false
            )

            UIPasteboard.general.setItems([
                [
                    UIPasteboard.attributed: data,
                    UTType.plainText.identifier: attributedString.string
                ]
            ])

            return
        } catch {
            print("Serialization error: \(error)")
        }

        super.copy(sender)
    }

    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        if action == #selector(UIResponderStandardEditActions.paste(_:)) {
            return true
        }

        return super.canPerformAction(action, withSender: sender)
    }
    
    public func initUndoRedoButons() {
        let editor = UIApplication.getEVC()
        let canUndo = undoManager?.canUndo == true
        let canRedo = undoManager?.canRedo == true
        editor.undoBarButton?.isEnabled = canUndo
        editor.redoBarButton?.isEnabled = canRedo
        (editor.undoBarButton?.customView as? UIControl)?.isEnabled = canUndo
        (editor.redoBarButton?.customView as? UIControl)?.isEnabled = canRedo
    }
    
    public func isTodo(at location: Int) -> Bool {
        let storage = self.textStorage
        
        if storage.length > location, storage.attribute(.todo, at: location, effectiveRange: nil) != nil {
            return true
        }
        
        let range = (storage.string as NSString).paragraphRange(for: NSRange(location: location, length: 0))
        let string = storage.attributedSubstring(from: range).string as NSString
        
        var length = string.range(of: "- [ ]").length
        if length == 0 {
            length = string.range(of: "- [x]").length
        }
        
        if length > 0 {
            let upper = range.location + length
            if location >= range.location && location <= upper {
                return true
            }
        }
        
        return false
    }

    public func isImage(at location: Int) -> Bool {
        return textStorage.getMeta(at: location) != nil
    }

    public func isLink(at location: Int) -> Bool {
        let storage = self.textStorage

        if storage.length > location, storage.attribute(.link, at: location, effectiveRange: nil) != nil {
            return true
        }

        return false
    }

    public func isWikiLink(at location: Int) -> Bool {
        let storage = self.textStorage

        if storage.length > location, let path = storage.attribute(.link, at: location, effectiveRange: nil) as? String, path.starts(with: "fsnotes://find?id=") {
            return true
        }

        return false
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)

        guard let sceneDelegate = window?.windowScene?.delegate as? SceneDelegate else {
            return
        }

        sceneDelegate.editorController.themeObserver()
    }
}

struct Undo {
    var range: NSRange
    var string: NSAttributedString
}
